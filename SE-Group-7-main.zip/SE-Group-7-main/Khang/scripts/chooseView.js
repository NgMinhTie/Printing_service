document.getElementById("AdminView").onclick = function () {
    window.location.href = "viewstudent.html?id=11223344";
}

document.getElementById("StudentList").onclick = function () {
  window.location.href = "admin_student.html";
};
