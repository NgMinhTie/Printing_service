document
  .getElementById("Home")
  .addEventListener("click", async function (event) {
    window.location.href = `${window.location.origin}/Khang/home.html`;
  });
